// traditional function
const fungsi1 = function (a) {
  return a + 100;
};

// arrow function
const fungsi2 = (a) => {
  return a + 100;
};

// arrow function tanpa {} dan return
const fungsi3 = (a) => a + 100;

// arrow function tanpa ()
const fungsi4 = a => a + 100;