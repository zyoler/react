// Sintaks spread => memecah/mengeluarkan elemen array

let numbers1 = [1, 2, 3, 4,];
let numbers2 = [5, 6, 7];

let numbers3 = [...numbers1, ...numbers2];

console.log(numbers3);