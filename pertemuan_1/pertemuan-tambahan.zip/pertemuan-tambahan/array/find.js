let numbers = [1, 2, 3, 4, 5, 6];

// bilangan genap pertama
let evenNumber = numbers.find(n => n % 2 === 0);
console.log(evenNumber);