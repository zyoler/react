// OR

// jika kiri false/null/undefined, maka kanan
// jika kiri selain di atas, maka kiri (dia sendiri)

let nama1;
let nama2 = nama1 || "Dion";

console.log(nama2);